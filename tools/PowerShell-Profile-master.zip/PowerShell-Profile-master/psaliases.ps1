Set-Alias vs devenv
Set-Alias g git
Set-Alias l Get-ChildItem
Set-Alias c code
